// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xaxi_dma.h"

extern XAxi_dma_Config XAxi_dma_ConfigTable[];

XAxi_dma_Config *XAxi_dma_LookupConfig(u16 DeviceId) {
	XAxi_dma_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XAXI_DMA_NUM_INSTANCES; Index++) {
		if (XAxi_dma_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAxi_dma_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAxi_dma_Initialize(XAxi_dma *InstancePtr, u16 DeviceId) {
	XAxi_dma_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAxi_dma_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAxi_dma_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

