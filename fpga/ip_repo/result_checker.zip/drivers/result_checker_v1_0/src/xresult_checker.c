// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xresult_checker.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XResult_checker_CfgInitialize(XResult_checker *InstancePtr, XResult_checker_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XResult_checker_Start(XResult_checker *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XResult_checker_ReadReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XResult_checker_WriteReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XResult_checker_IsDone(XResult_checker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XResult_checker_ReadReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XResult_checker_IsIdle(XResult_checker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XResult_checker_ReadReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XResult_checker_IsReady(XResult_checker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XResult_checker_ReadReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XResult_checker_EnableAutoRestart(XResult_checker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XResult_checker_WriteReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XResult_checker_DisableAutoRestart(XResult_checker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XResult_checker_WriteReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XResult_checker_Get_error_num(XResult_checker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XResult_checker_ReadReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_ERROR_NUM_DATA);
    return Data;
}

void XResult_checker_Set_test_frame_num(XResult_checker *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XResult_checker_WriteReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_TEST_FRAME_NUM_DATA, Data);
}

u32 XResult_checker_Get_test_frame_num(XResult_checker *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XResult_checker_ReadReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_TEST_FRAME_NUM_DATA);
    return Data;
}

void XResult_checker_InterruptGlobalEnable(XResult_checker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XResult_checker_WriteReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_GIE, 1);
}

void XResult_checker_InterruptGlobalDisable(XResult_checker *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XResult_checker_WriteReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_GIE, 0);
}

void XResult_checker_InterruptEnable(XResult_checker *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XResult_checker_ReadReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_IER);
    XResult_checker_WriteReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_IER, Register | Mask);
}

void XResult_checker_InterruptDisable(XResult_checker *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XResult_checker_ReadReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_IER);
    XResult_checker_WriteReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XResult_checker_InterruptClear(XResult_checker *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    //XResult_checker_WriteReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_ISR, Mask);
}

u32 XResult_checker_InterruptGetEnabled(XResult_checker *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XResult_checker_ReadReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_IER);
}

u32 XResult_checker_InterruptGetStatus(XResult_checker *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    // Current Interrupt Clear Behavior is Clear on Read(COR).
    return XResult_checker_ReadReg(InstancePtr->Control_BaseAddress, XRESULT_CHECKER_CONTROL_ADDR_ISR);
}

