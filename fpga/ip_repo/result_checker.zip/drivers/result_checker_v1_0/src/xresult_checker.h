// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XRESULT_CHECKER_H
#define XRESULT_CHECKER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xresult_checker_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XResult_checker_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XResult_checker;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XResult_checker_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XResult_checker_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XResult_checker_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XResult_checker_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XResult_checker_Initialize(XResult_checker *InstancePtr, u16 DeviceId);
XResult_checker_Config* XResult_checker_LookupConfig(u16 DeviceId);
int XResult_checker_CfgInitialize(XResult_checker *InstancePtr, XResult_checker_Config *ConfigPtr);
#else
int XResult_checker_Initialize(XResult_checker *InstancePtr, const char* InstanceName);
int XResult_checker_Release(XResult_checker *InstancePtr);
#endif

void XResult_checker_Start(XResult_checker *InstancePtr);
u32 XResult_checker_IsDone(XResult_checker *InstancePtr);
u32 XResult_checker_IsIdle(XResult_checker *InstancePtr);
u32 XResult_checker_IsReady(XResult_checker *InstancePtr);
void XResult_checker_EnableAutoRestart(XResult_checker *InstancePtr);
void XResult_checker_DisableAutoRestart(XResult_checker *InstancePtr);

u32 XResult_checker_Get_error_num(XResult_checker *InstancePtr);
void XResult_checker_Set_test_frame_num(XResult_checker *InstancePtr, u32 Data);
u32 XResult_checker_Get_test_frame_num(XResult_checker *InstancePtr);

void XResult_checker_InterruptGlobalEnable(XResult_checker *InstancePtr);
void XResult_checker_InterruptGlobalDisable(XResult_checker *InstancePtr);
void XResult_checker_InterruptEnable(XResult_checker *InstancePtr, u32 Mask);
void XResult_checker_InterruptDisable(XResult_checker *InstancePtr, u32 Mask);
void XResult_checker_InterruptClear(XResult_checker *InstancePtr, u32 Mask);
u32 XResult_checker_InterruptGetEnabled(XResult_checker *InstancePtr);
u32 XResult_checker_InterruptGetStatus(XResult_checker *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
